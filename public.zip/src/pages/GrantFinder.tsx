function GrantFinder() {
  return (
    <div>
      <h1>Grant Finder</h1>
      <p>Search and match grants here.</p>
    </div>
  )
}

export default GrantFinder